using Terraria.ModLoader;

namespace DragonitesMod
{
	class DragonitesMod : Mod
	{
		public DragonitesMod()
		{
		}
	}
}
